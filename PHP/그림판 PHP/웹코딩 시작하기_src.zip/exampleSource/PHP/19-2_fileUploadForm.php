<!DOCTYPE html>
<html>
<head>
</head>
<body>
  <h1>파일 업로드</h1>
  <form name="fileUpload" method="post" action="19-3_fileUpload.php"
  enctype="multipart/form-data">
    <input type="file" name="myImage" />
    <input type="submit" value="파일등록"/>
  </form>
</body>
</html>
