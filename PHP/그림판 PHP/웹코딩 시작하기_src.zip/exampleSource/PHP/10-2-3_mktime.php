<?php
  ini_set('date.timezone','Asia/Seoul');
  echo "2017년 12월 25일 9시 15분 10초 의 타임스탬프는? <br />";
  echo mktime(9, 15, 10, 12, 25, 2017);
?>
