<?php
  class people{

    //생성자
    function __construct(){
      echo "사람은 돈을 좋아한다 <br />";
    }
    
  }
?>
