<?php
  //배열 선언
  $earth = array();

  //earth의 nation인덱스에 'korea'를 대입
  $earth['nation'] = 'korea';

  //earth배열의 nation인덱스를 출력
  echo "earth 배열의 nation인덱스는 ".$earth['nation'];
?>
