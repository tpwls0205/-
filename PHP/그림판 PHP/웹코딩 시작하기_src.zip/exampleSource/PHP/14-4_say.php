<?php
  class say{
    function __construct($word){
      echo $word;
    }
  }
?>
