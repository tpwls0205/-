<?php
  $str = "Hello World";
  $changeWord = str_replace("World","Tae young", $str);
  echo $changeWord;
?>
