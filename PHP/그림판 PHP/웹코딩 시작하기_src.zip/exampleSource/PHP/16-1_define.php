<?php
  echo "상수 MYSQLI_ASSOC의 값은 ".MYSQLI_ASSOC."<br />";
  echo "상수 MYSQLI_NUM의 값은 ".MYSQLI_NUM."<br />";
  echo "상수 MYSQLI_BOTH의 값은 ".MYSQLI_BOTH;
?>
