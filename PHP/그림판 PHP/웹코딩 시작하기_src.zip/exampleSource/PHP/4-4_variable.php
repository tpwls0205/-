<?php
  $birthMonth = 4;

  echo "저는 {$birthMonth}월에 태어났습니다.";
?>
