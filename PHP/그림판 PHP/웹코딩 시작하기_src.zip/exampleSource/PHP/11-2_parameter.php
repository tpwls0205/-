<?php
  function hello($name){
    echo "hello ".$name;
  }

  hello('Kim Yu Na');
?>
