<?php
  class hello{
    function __construct($param){
      echo $param;
    }
  }

  $hello = new hello('say Hello');
?>
