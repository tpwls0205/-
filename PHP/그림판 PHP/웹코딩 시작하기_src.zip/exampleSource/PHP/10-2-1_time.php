<?php
  ini_set('date.timezone','Asia/Seoul');
  echo '1970년 1월 1일 0시 0분 0초로부터 '.time().'초가 지났습니다.';
?>
