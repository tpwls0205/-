<?php
  $str = "welcome to my web page";

  echo $str."의 문자열 길이는 ".strlen($str)."입니다."
?>
