<?php
  //배열 선언
  $earth = array();

  //earth의 0인덱스에 'korea'를 대입
  $earth[0] = 'korea';

  //earth배열의 0인덱스를 출력
  echo "earth 배열의 0인덱스는 ".$earth[0];
?>
