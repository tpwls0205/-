<?php
  include_once "./14-4_say.php";
  $say = new say('Hello World');
?>
