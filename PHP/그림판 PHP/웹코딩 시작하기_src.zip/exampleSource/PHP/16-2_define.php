<?php
  // 상수 myRobot를 선언
  define("myRobot", "AIBO");
  echo "상수 myRobot의 값은 ".myRobot."<br />";

  // 상수 myRobot의 값을 변경
  define("myRobot", "ASIMO");
  echo "값 변경 시도 후 상수 myRobot의 값은 ".myRobot."<br />";
?>
