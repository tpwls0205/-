<?php
  //존재 하지 않는 error.php 파일 불러오기
  include "./error.php";
?>
