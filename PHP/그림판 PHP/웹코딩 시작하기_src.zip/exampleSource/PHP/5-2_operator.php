<?php
  // += 활용
  $num = 10;
  $num += 2;
  echo "[+=사용] 변수 num의 값은 ".$num."<br />";

  // -= 활용
  $num = 10;
  $num -= 2;
  echo "[-=사용] 변수 num의 값은 ".$num."<br />";

  // *= 활용
  $num = 10;
  $num *= 2;
  echo "[*=사용] 변수 num의 값은 ".$num."<br />";

  // /= 활용
  $num = 10;
  $num /= 2;
  echo "[/=사용] 변수 num의 값은 ".$num."<br />";

  // %= 활용
  $num = 10;
  $num %= 3;
  echo "[/=사용] 변수 num의 값은 ".$num."<br />";

  // .= 활용
  $city = '서울';
  $city .= '특별시';
  echo "[.=사용] 변수 city의 값은 ".$city;
?>
