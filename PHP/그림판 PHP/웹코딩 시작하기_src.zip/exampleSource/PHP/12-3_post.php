<?php
  echo "이메일 주소 입력값 " .$_POST['email']."<br />";
  echo "비밀번호 입력값 " .$_POST['password'];
?>
