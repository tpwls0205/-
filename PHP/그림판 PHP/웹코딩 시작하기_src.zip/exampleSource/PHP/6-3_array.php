<?php
  $fruit = array();

  array_push($fruit, 'apple', 'banana', 'grape', 'coconut', 'tangerine', 'water melon');

  echo $fruit[0]."<br />";
  echo $fruit[1]."<br />";
  echo $fruit[2]."<br />";
  echo $fruit[3]."<br />";
  echo $fruit[4]."<br />";
  echo $fruit[5]."<br />";
?>
