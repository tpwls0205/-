<?php
  $greeting = "hello world";

  echo $greeting;
?>
