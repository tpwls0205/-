<?php

  //outputHello함수 생성
  function outputHello(){
    echo "hello world";
  }

  //outputHello함수 호출
  outputHello();
?>
