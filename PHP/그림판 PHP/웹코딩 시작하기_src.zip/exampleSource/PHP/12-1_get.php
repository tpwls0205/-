<?php
  echo "GET['type']는 ".$_GET['type']."<br />";
  echo "GET['mobile']는 ".$_GET['mobile']."<br />";
?>
