<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>ping 속성사용하기</title>
</head>
<body>
   <a href="http://www.everdevel.com" ping="./21-1-3_receivePing.php?linkNum=1.php">
      에버디벨에 이동
   </a>
</body>
</html>
